package com.ownly.inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ownly.inventory.entity.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory, Long>{

}
