<%@ page isELIgnored="false" %>
<%@ include file="../common/header.jsp" %>

<div class="product-container">

    <c:forEach var="product" items="${products}">

        <div class="product-card">

            <h3>${product.productName}</h3>

            <p>Category : ${product.category}</p>

            <h4>₹ ${product.price}</h4>

            <p>Stock : ${product.stock}</p>

            <button>Add</button>

        </div>

    </c:forEach>

</div>

<%@ include file="../common/footer.jsp" %>